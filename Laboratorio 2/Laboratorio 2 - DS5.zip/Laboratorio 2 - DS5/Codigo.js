// Problema 1: ¿Qué es Javascript y en qué se asemeja a Java?
document.getElementById("respuesta-js").innerText = "JavaScript es un lenguaje de programación diseñado para desarrollar aplicaciones interactivas en la web. A pesar de que su nombre parece estar relacionado con Java, ambos lenguajes son distintos en su propósito y funcionamiento. Mientras que Java es un lenguaje de programación compilado y de uso general que se utiliza en diversas plataformas, JavaScript es un lenguaje interpretado que se ejecuta directamente en el navegador, permitiendo la creación de experiencias dinámicas en sitios web. Aunque ambos comparten el enfoque orientado a objetos, su implementación y uso difieren significativamente.";


// Problema 2: Declarar dos variables con "var" y realizar operaciones matemáticas
var Numero1 = 6;
var Numero2 = 2;
console.log("Suma: " + (Numero1 + Numero2)); 
console.log("Resta: " + (Numero1 - Numero2)); 
console.log("Multiplicación: " + (Numero1 * Numero2)); 
console.log("División: " + (Numero1 / Numero2)); 


// Problema 3: Declarar dos variables con "let" y concatenarlas
let Cadena1 = "Quien es ese";
let Cadena2 = " Pokemon!?";
console.log(Cadena1 + Cadena2); 


// Problema 4: Declarar dos variables con "const" y mostrar su tipo de dato
const Numero_Const = 10;
const Cadena_Const = "Cadena";
console.log("Tipo de dato de Numero_Const: " + typeof Numero_Const); 
console.log("Tipo de dato de Cadena_Const: " + typeof Cadena_Const); 


// Problema 5: Declarar una variable tipo Objeto con 4 llaves
const Entrenador = {
    Edad: 10, //Dato tipo Number
    Nombre: "Ash Ketchup", //Dato tipo String
    Campeon: false, //Dato tipo Booleano
    Medallas: {} //Dato tipo ObjetoVacio
};
console.log(Entrenador);


// Problema 6: Función que devuelve la suma de múltiplos de 3 o 5 menores que un número dado
function Suma_Multiplos(Limite) {
    let Suma = 0;
    for (let i = 1; i < Limite; i++) {
        if (i % 3 === 0 || i % 5 === 0) {
            Suma += i;
        }
    }
    return Suma;
}


console.log("Suma de multiplos de 3 y 5 menores que el numero 10: " + Suma_Multiplos(10)); 